@echo off
title IMI Local Backend Server (Port 4000)
cd /d "%~dp0"

echo ====================================================
echo Starting IMI Local Backend Server on Port 4000
echo ====================================================
echo Working Directory: %CD%
echo Node Version:
node -v
echo.

node src/index.js

if %errorlevel% neq 0 (
    echo.
    echo ====================================================
    echo [ERROR] Node.js process stopped with exit code %errorlevel%
    echo ====================================================
)
pause
