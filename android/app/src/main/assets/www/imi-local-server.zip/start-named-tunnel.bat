@echo off
title Cloudflare Managed Named Tunnel
cd /d "%~dp0"

echo ====================================================
echo Starting Cloudflare Named / Managed Tunnel
echo ====================================================
echo.
echo Option 1: Run with Token (Cloudflare Zero Trust Dashboard)
echo Run: cloudflared.exe tunnel run --token YOUR_TUNNEL_TOKEN
echo.
echo Option 2: Run with local config.yml
echo Run: cloudflared.exe tunnel --config config.yml run
echo ====================================================
echo.

if exist "config.yml" (
    echo Found config.yml! Starting tunnel with config.yml...
    cloudflared.exe tunnel --config config.yml run
) else (
    echo Note: Create a config.yml file or paste your Cloudflare Zero Trust tunnel token.
    echo Example: cloudflared.exe tunnel run --token YOUR_TOKEN
)
pause
