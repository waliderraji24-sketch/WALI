import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:4000/api/v1';
const TOKEN = process.argv[2]; // Pass token as first argument

if (!TOKEN) {
  console.log('Usage: node test-api.js <FIREBASE_ID_TOKEN>');
  process.exit(1);
}

const headers = {
  'Authorization': `Bearer ${TOKEN}`,
  'Content-Type': 'application/json'
};

async function testAll() {
  console.log('--- Starting IMI Local Server Phase 2 Tests ---');

  // 1. Health Check
  try {
    const health = await fetch(`${BASE_URL}/health`);
    console.log('1. Health Check:', await health.json());
  } catch (e) { console.error('Health failed:', e.message); }

  // 2. Auth Sync
  try {
    const sync = await fetch(`${BASE_URL}/auth/sync`, { method: 'POST', headers });
    const syncData = await sync.json();
    console.log('2. User Sync:', syncData);
    if (!syncData.success) throw new Error('Sync failed');
  } catch (e) { console.error('Sync failed:', e.message); }

  // 3. Create Conversation
  let conversationId;
  try {
    const conv = await fetch(`${BASE_URL}/messages/conversations`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ targetUserId: 'TEST_TARGET_UID' })
    });
    const convData = await conv.json();
    console.log('3. Create Conversation:', convData);
    conversationId = convData.conversationId;
  } catch (e) { console.error('Conversation failed:', e.message); }

  // 4. Send Message
  if (conversationId) {
    try {
      const msg = await fetch(`${BASE_URL}/messages`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          conversationId,
          content: 'Hello from local test script!',
          type: 'text'
        })
      });
      console.log('4. Send Message:', await msg.json());
    } catch (e) { console.error('Message failed:', e.message); }
  }

  // 5. Invalid Token Test
  try {
    const badAuth = await fetch(`${BASE_URL}/auth/sync`, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer INVALID_TOKEN' }
    });
    console.log('5. Unauthorized Test (Expected 401):', badAuth.status);
  } catch (e) { console.error('Unauthorized test error:', e.message); }

  console.log('--- Tests Completed ---');
}

testAll();
