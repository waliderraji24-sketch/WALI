import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import db from '../db/index.js';

const router = express.Router();

// Synchronize authenticated Firebase user with local database
router.post('/sync', verifyToken, async (req, res) => {
  const { uid, email, name, picture } = req.user;

  try {
    // Upsert user in local database
    await db('users')
      .insert({
        id: uid,
        email: email,
        display_name: name || null,
        photo_url: picture || null,
        last_sync: db.fn.now()
      })
      .onConflict('id')
      .merge({
        email: email,
        display_name: name || null,
        photo_url: picture || null,
        last_sync: db.fn.now()
      });

    res.json({ 
      success: true, 
      message: 'User synchronized successfully', 
      user: { uid, email, name } 
    });
  } catch (error) {
    console.error('[IMI Auth] Sync error:', error);
    res.status(500).json({ error: 'Internal Server Error', message: 'Failed to sync user' });
  }
});

export default router;
