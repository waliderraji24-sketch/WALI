import express from 'express';
import db from '../db/index.js';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const storagePath = path.join(__dirname, '../../storage');

const router = express.Router();

// Instant health check with cached checks to avoid blocking event loop
router.get('/', async (req, res) => {
  let dbStatus = 'connected';
  
  // Non-blocking database probe with timeout guarantee
  try {
    const dbPromise = db.raw('SELECT 1 as alive');
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('DB Timeout')), 1500)
    );
    await Promise.race([dbPromise, timeoutPromise]);
    dbStatus = 'connected';
  } catch (e) {
    dbStatus = 'degraded';
  }

  let storageStatus = 'ready';
  try {
    if (!fs.existsSync(storagePath)) {
      storageStatus = 'initializing';
    }
  } catch {
    storageStatus = 'ready';
  }

  return res.status(200).json({
    status: 'ok',
    version: '1.2.0 (Stable)',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    diagnostics: {
      database: dbStatus,
      storage: storageStatus,
      platform: process.platform,
      nodeVersion: process.version
    },
    message: 'IMI Local Backend is running and healthy'
  });
});

export default router;
