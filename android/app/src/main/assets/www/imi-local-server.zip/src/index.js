import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import rateLimit from 'express-rate-limit';

import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import mediaRoutes from './routes/media.js';
import messageRoutes from './routes/messages.js';
import { initDb } from './db/index.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ==========================================
// Process-Level Resilience & Crash Prevention
// ==========================================
process.on('uncaughtException', (err) => {
  console.error('[IMI CRITICAL ERROR] Uncaught Exception:', err.message);
  console.error(err.stack);
  // Keep process alive unless it's a fatal system resource exhaustion
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[IMI WARNING] Unhandled Promise Rejection at:', promise);
  console.error('[IMI WARNING] Reason:', reason);
});

process.on('SIGINT', () => {
  console.log('\n[IMI Local Server] Gracefully shutting down (SIGINT)...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n[IMI Local Server] Gracefully shutting down (SIGTERM)...');
  process.exit(0);
});

process.on('exit', (code) => {
  console.log(`[IMI Local Server] Process exited with code: ${code}`);
});

// Initialize Database in background with safe error capture
initDb().then(() => {
  console.log('[IMI DB] SQLite database synchronized and ready');
}).catch(err => {
  console.error('[IMI DB] Database initialization warning:', err.message);
});

const app = express();
const PORT = parseInt(process.env.LOCAL_PORT || '4000', 10);
const HOST = '0.0.0.0';

// ==========================================
// 1. Trust Proxy (Crucial for Cloudflare Tunnel)
// ==========================================
app.set('trust proxy', 1);

// ==========================================
// 2. Security & Header Middlewares
// ==========================================
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
  contentSecurityPolicy: false // Allows API communication without strict CSP blocking
}));

app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin']
}));

// ==========================================
// 3. Body Parsers & Request Logging
// ==========================================
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Custom compact request logger to monitor incoming traffic without noise
app.use(morgan(':date[iso] | :method :url :status :response-time ms - :res[content-length] (from :remote-addr)'));

// ==========================================
// 4. Safe Rate Limiting (Cloudflare-Compatible)
// ==========================================
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 2000, // Generous limit for real-time mobile app calls
  standardHeaders: true,
  legacyHeaders: false,
  validate: {
    xForwardedForHeader: false, // Prevents ERR_ERL_UNEXPECTED_X_FORWARDED_FOR crash
    trustProxy: false
  },
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too Many Requests',
      message: 'Rate limit exceeded, please retry shortly'
    });
  }
});

app.use('/api/', apiLimiter);

// ==========================================
// 5. Static Storage Routes (Media & Files)
// ==========================================
app.use('/storage', express.static(path.join(__dirname, '../storage'), {
  maxAge: '1d',
  setHeaders: (res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
}));

// ==========================================
// 6. API Route Handlers
// ==========================================
app.use('/api/v1/health', healthRoutes);
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/media', mediaRoutes);
app.use('/api/v1/messages', messageRoutes);

// Root informational endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    name: 'IMI Local Backend Service',
    status: 'online',
    version: '1.2.0',
    port: PORT,
    endpoints: {
      health: '/api/v1/health',
      auth: '/api/v1/auth',
      media: '/api/v1/media',
      messages: '/api/v1/messages',
      storage: '/storage'
    }
  });
});

// ==========================================
// 7. 404 & Global Error Handling
// ==========================================
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint Not Found', path: req.originalUrl });
});

app.use((err, req, res, next) => {
  console.error('[IMI EXPRESS ERROR Handler]:', err.message);
  if (err.stack) console.error(err.stack);
  res.status(500).json({ 
    error: 'Internal Server Error', 
    message: err.message || 'An unexpected error occurred'
  });
});

// ==========================================
// 8. Server Boot & Cloudflare Keep-Alive Sync
// ==========================================
const server = app.listen(PORT, HOST, () => {
  console.log('====================================================');
  console.log(`[IMI Local Server] Server listening on http://${HOST}:${PORT}`);
  console.log(`[IMI Local Server] Local Health check: http://127.0.0.1:${PORT}/api/v1/health`);
  console.log('====================================================');
});

// Align Keep-Alive timeouts with Cloudflare Edge Proxy (Prevents 502/524 connection reset bugs)
server.keepAliveTimeout = 65000; // 65 seconds
server.headersTimeout = 66000;   // 66 seconds
