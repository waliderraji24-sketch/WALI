import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import db from '../db/index.js';

const router = express.Router();

// Middleware to check conversation membership
async function checkMembership(userId, conversationId) {
  const member = await db('conversation_members')
    .where({ user_id: userId, conversation_id: conversationId })
    .first();
  return !!member;
}

// Get messages for a conversation
router.get('/:conversationId/messages', verifyToken, async (req, res) => {
  const { uid } = req.user;
  const { conversationId } = req.params;

  try {
    const isMember = await checkMembership(uid, conversationId);
    if (!isMember) {
      return res.status(403).json({ error: 'Forbidden', message: 'Not a member of this conversation' });
    }

    const messages = await db('messages')
      .where({ conversation_id: conversationId })
      .orderBy('created_at', 'asc')
      .limit(100);

    res.json({ success: true, messages });
  } catch (error) {
    console.error('[IMI Messages] Error fetching messages:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Send a new message
router.post('/', verifyToken, async (req, res) => {
  const { uid } = req.user;
  const { conversationId, content, type, mediaUrl } = req.body;

  if (!conversationId || (!content && !mediaUrl)) {
    return res.status(400).json({ error: 'Bad Request', message: 'Missing required fields' });
  }

  try {
    const isMember = await checkMembership(uid, conversationId);
    if (!isMember) {
      return res.status(403).json({ error: 'Forbidden', message: 'Not a member of this conversation' });
    }

    const [messageId] = await db('messages').insert({
      conversation_id: conversationId,
      sender_id: uid,
      content: content || null,
      type: type || 'text',
      media_url: mediaUrl || null
    });

    const newMessage = await db('messages').where({ id: messageId }).first();

    res.status(201).json({ success: true, message: newMessage });
  } catch (error) {
    console.error('[IMI Messages] Error sending message:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Create a new private conversation (or find existing)
router.post('/conversations', verifyToken, async (req, res) => {
  const { uid } = req.user;
  const { targetUserId } = req.body;

  if (!targetUserId) {
    return res.status(400).json({ error: 'Bad Request', message: 'Target user ID required' });
  }

  try {
    // Check if target user exists in local DB
    const targetUser = await db('users').where({ id: targetUserId }).first();
    if (!targetUser) {
      return res.status(404).json({ error: 'Not Found', message: 'Target user not synchronized' });
    }

    // Transaction to create conversation and members
    const conversationId = await db.transaction(async trx => {
      const [id] = await trx('conversations').insert({ type: 'private' });
      await trx('conversation_members').insert([
        { conversation_id: id, user_id: uid },
        { conversation_id: id, user_id: targetUserId }
      ]);
      return id;
    });

    res.status(201).json({ success: true, conversationId });
  } catch (error) {
    console.error('[IMI Messages] Error creating conversation:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

export default router;
