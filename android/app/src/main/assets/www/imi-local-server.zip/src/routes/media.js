import express from 'express';
import uploadMiddleware from '../middleware/upload.js';
import { verifyToken } from '../middleware/auth.js';
import db from '../db/index.js';

const router = express.Router();

// Helper to record media in DB
async function recordMedia(req, category) {
  const { uid } = req.user;
  const { filename, mimetype, size } = req.file;
  
  await db('media').insert({
    owner_id: uid,
    file_path: `/storage/${category}/${filename}`,
    file_name: filename,
    mime_type: mimetype,
    file_size: size,
    category: category
  });
}

// All media routes are protected
router.use(verifyToken);

// Upload a single avatar
router.post('/avatar', uploadMiddleware.single('avatar'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
  try {
    await recordMedia(req, 'avatars');
    const fileUrl = `/storage/avatars/${req.file.filename}`;
    res.json({ message: 'Avatar uploaded successfully', url: fileUrl });
  } catch (error) {
    res.status(500).json({ error: 'Failed to record media' });
  }
});

// Upload media (images, videos)
router.post('/upload', uploadMiddleware.single('media'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
  let category = 'documents';
  if (req.file.mimetype.startsWith('image/')) category = 'images';
  else if (req.file.mimetype.startsWith('video/')) category = 'videos';
  else if (req.file.mimetype.startsWith('audio/')) category = 'audio';

  try {
    await recordMedia(req, category);
    const fileUrl = `/storage/${category}/${req.file.filename}`;
    res.json({ message: 'Media uploaded successfully', url: fileUrl, type: category });
  } catch (error) {
    res.status(500).json({ error: 'Failed to record media' });
  }
});

// Upload a reel
router.post('/reel', uploadMiddleware.single('video'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No reel uploaded' });
  }
  
  try {
    await recordMedia(req, 'reels');
    const fileUrl = `/storage/reels/${req.file.filename}`;
    res.json({ message: 'Reel uploaded successfully', url: fileUrl });
  } catch (error) {
    res.status(500).json({ error: 'Failed to record media' });
  }
});

export default router;
