import admin from 'firebase-admin';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const serviceAccountPath = path.join(__dirname, '../../firebase-service-account.json');

let firebaseApp = null;

try {
  if (fs.existsSync(serviceAccountPath)) {
    const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
    console.log('[IMI Firebase] Firebase Admin initialized with service account file');
  } else if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
    console.log('[IMI Firebase] Firebase Admin initialized from environment variable');
  } else if (process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT) {
    firebaseApp = admin.initializeApp({
      projectId: process.env.FIREBASE_PROJECT_ID || process.env.GOOGLE_CLOUD_PROJECT
    });
    console.log('[IMI Firebase] Firebase Admin initialized with Project ID');
  } else {
    firebaseApp = admin.initializeApp({
      projectId: 'cosmic-altar-m6shk'
    });
    console.log('[IMI Firebase] Firebase Admin initialized with default Project ID');
  }
} catch (e) {
  console.warn('[IMI Firebase] Firebase Admin init notice:', e.message);
}

export const getAuth = () => {
  try {
    return admin.auth();
  } catch (err) {
    return null;
  }
};

export default firebaseApp;
