import knex from 'knex';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, '../../data/imi_data.db');

const db = knex({
  client: 'sqlite3',
  connection: {
    filename: dbPath,
  },
  useNullAsDefault: true,
});

export async function initDb() {
  const hasUsers = await db.schema.hasTable('users');
  if (!hasUsers) {
    await db.schema.createTable('users', (table) => {
      table.string('id').primary(); // Firebase UID
      table.string('email').unique().notNullable();
      table.string('display_name');
      table.string('photo_url');
      table.timestamp('created_at').defaultTo(db.fn.now());
      table.timestamp('last_sync').defaultTo(db.fn.now());
    });
  }

  const hasConversations = await db.schema.hasTable('conversations');
  if (!hasConversations) {
    await db.schema.createTable('conversations', (table) => {
      table.increments('id').primary();
      table.string('type').defaultTo('private'); // private or group
      table.string('name');
      table.timestamp('created_at').defaultTo(db.fn.now());
    });
  }

  const hasMembers = await db.schema.hasTable('conversation_members');
  if (!hasMembers) {
    await db.schema.createTable('conversation_members', (table) => {
      table.integer('conversation_id').references('id').inTable('conversations').onDelete('CASCADE');
      table.string('user_id').references('id').inTable('users').onDelete('CASCADE');
      table.primary(['conversation_id', 'user_id']);
      table.timestamp('joined_at').defaultTo(db.fn.now());
    });
  }

  const hasMessages = await db.schema.hasTable('messages');
  if (!hasMessages) {
    await db.schema.createTable('messages', (table) => {
      table.increments('id').primary();
      table.integer('conversation_id').references('id').inTable('conversations').onDelete('CASCADE');
      table.string('sender_id').references('id').inTable('users');
      table.text('content');
      table.string('type').defaultTo('text'); // text, image, video, etc
      table.string('media_url');
      table.timestamp('created_at').defaultTo(db.fn.now());
    });
  }

  const hasMedia = await db.schema.hasTable('media');
  if (!hasMedia) {
    await db.schema.createTable('media', (table) => {
      table.increments('id').primary();
      table.string('owner_id').references('id').inTable('users');
      table.string('file_path').notNullable();
      table.string('file_name').notNullable();
      table.string('mime_type');
      table.integer('file_size');
      table.string('category'); // avatars, reels, images, etc
      table.timestamp('uploaded_at').defaultTo(db.fn.now());
    });
  }

  console.log('[IMI DB] Database initialized successfully');
}

export default db;
