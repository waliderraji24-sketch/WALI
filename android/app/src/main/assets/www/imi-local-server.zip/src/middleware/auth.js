import { getAuth } from '../utils/firebase.js';

export const verifyToken = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized', message: 'No token provided' });
  }

  const idToken = authHeader.split('Bearer ')[1];
  const auth = getAuth();

  if (!auth) {
    return res.status(500).json({ error: 'Configuration Error', message: 'Firebase Auth is not initialized on server' });
  }

  try {
    const decodedToken = await auth.verifyIdToken(idToken);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('[IMI Auth] Token verification failed:', error.message);
    return res.status(401).json({ error: 'Unauthorized', message: 'Invalid or expired token' });
  }
};
