@echo off
echo ==============================================
echo Creating IMI Local Storage & Data Directories
echo ==============================================
mkdir data 2>nul
mkdir storage\avatars 2>nul
mkdir storage\images 2>nul
mkdir storage\videos 2>nul
mkdir storage\audio 2>nul
mkdir storage\reels 2>nul
mkdir storage\documents 2>nul
echo Storage and data directories created successfully.
pause
