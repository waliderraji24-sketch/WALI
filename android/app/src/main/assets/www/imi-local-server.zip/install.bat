@echo off
echo ==============================================
echo Installing dependencies for IMI Local Server
echo ==============================================
npm install
echo.
echo Dependencies installed successfully.
pause
