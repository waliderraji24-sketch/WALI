@echo off
echo ==============================================
echo Starting Cloudflare Tunnel for IMI Local Server
echo ==============================================
echo Exposing http://localhost:4000 securely over HTTPS...
echo.
cloudflared tunnel --url http://localhost:4000
pause
