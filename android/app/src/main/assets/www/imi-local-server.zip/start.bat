@echo off
echo ==============================================
echo Starting IMI Local Server
echo ==============================================
npm start
pause
